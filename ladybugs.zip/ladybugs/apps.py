from django.apps import AppConfig


class LadybugsConfig(AppConfig):
    name = 'ladybugs'
